﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONTWiFiMaster.Function.Custom {

    public class CalibPowerConfigInfo {
        public string carrierfreq { get; set; }
        public string anten { get; set; }
        public string channelfreq { get; set; }
        public string register { get; set; }
        public string calibflag { get; set; }
        public string refference { get; set; }
    }
}
