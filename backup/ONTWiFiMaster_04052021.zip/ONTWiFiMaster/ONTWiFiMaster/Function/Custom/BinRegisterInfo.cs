﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONTWiFiMaster.Function.Custom {

    public class BinRegisterInfo {
        public string Address { get; set; }
        public string oldValue { get; set; }
        public string newValue { get; set; }
    }
}
