﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONTWiFiMaster.Function.Custom {
    public class RxLimitInfo {

        public string rangefreq { get; set; }
        public string wifi { get; set; }
        public string mcs { get; set; }
        public string power_Transmit { get; set; }
        public string PER { get; set; }
    }
}
